<script>
  const firebaseConfig = {
    apiKey: "AIzaSyC94QRRR4Pp1CR-zEr2t1rPvqeGfPzkDY0",
    authDomain: "vortex-855fc.firebaseapp.com",
    databaseURL: "https://vortex-855fc-default-rtdb.firebaseio.com",
    projectId: "vortex-855fc",
    storageBucket: "vortex-855fc.firebasestorage.app",
    messagingSenderId: "9078739581",
    appId: "1:9078739581:android:99e5d7011256fdc4c45714"
  };
  firebase.initializeApp(firebaseConfig);
</script>